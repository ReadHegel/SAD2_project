#dummy package module
version=1
